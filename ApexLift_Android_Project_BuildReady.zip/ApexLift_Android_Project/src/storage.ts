import { Capacitor } from '@capacitor/core';
import { CapacitorSQLite, SQLiteConnection, SQLiteDBConnection } from '@capacitor-community/sqlite';

const sqlite = new SQLiteConnection(CapacitorSQLite);
let db: SQLiteDBConnection | null = null;

/** Local-only SQLite database. No remote service or account. */
export async function initializeDatabase() {
  if (!Capacitor.isNativePlatform()) return null; // browser preview fallback
  db = await sqlite.createConnection('apexlift', false, 'no-encryption', 1, false);
  await db.open();
  await db.execute(`
    CREATE TABLE IF NOT EXISTS activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      activity TEXT NOT NULL, category TEXT NOT NULL,
      status TEXT NOT NULL, duration_minutes INTEGER DEFAULT 0,
      details TEXT DEFAULT '', activity_date TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS workout_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      day_index INTEGER NOT NULL, session_date TEXT NOT NULL,
      started INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS exercises (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER NOT NULL, name TEXT NOT NULL,
      position INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY(session_id) REFERENCES workout_sessions(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS workout_sets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      exercise_id INTEGER NOT NULL, set_number INTEGER NOT NULL,
      weight REAL, reps INTEGER, logged INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY(exercise_id) REFERENCES exercises(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS routine_templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      day_index INTEGER NOT NULL, exercise_name TEXT NOT NULL,
      position INTEGER NOT NULL DEFAULT 0
    );
  `);
  return db;
}
export async function getDatabase() { return db ?? initializeDatabase(); }

/** App boot entry: initializes local persistence once native shell is ready. */
export async function createApp() {
  try { await initializeDatabase(); }
  catch (error) { console.error('ApexLift SQLite initialization failed', error); }
}
