import { createApp } from './storage';
import html from '../www/index.html?raw';
import './style.css';

// Render the original single-file UI while explicitly re-attaching its inline
// stylesheet and script (scripts inserted via innerHTML do not execute).
const parsed = new DOMParser().parseFromString(html, 'text/html');
for (const style of parsed.head.querySelectorAll('style')) {
  const copy = document.createElement('style');
  copy.textContent = style.textContent ?? '';
  document.head.appendChild(copy);
}
const app = document.querySelector<HTMLDivElement>('#app')!;
app.innerHTML = parsed.body.innerHTML;
for (const sourceScript of parsed.body.querySelectorAll('script')) {
  const script = document.createElement('script');
  script.textContent = sourceScript.textContent ?? '';
  document.body.appendChild(script);
}
void createApp();
