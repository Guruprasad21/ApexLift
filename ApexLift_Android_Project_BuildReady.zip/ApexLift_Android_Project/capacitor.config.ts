import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.apexlift.tracker',
  appName: 'ApexLift',
  webDir: 'dist',
  bundledWebRuntime: false
};
export default config;
